#include <iostream>
#include <limits>

using namespace std;

using Port      = int;
using IPAddress = int;

class Socket {
public:
  Socket(Port p);
  void open();
  void close();
  void write(const char *buf);
private:
  Port port;
};

Socket::Socket(Port p) : port{ p } {
}

void Socket::open() {
  cout << "Socket opened" << endl;
}

void Socket::close() {
  cout << "Socket closed" << endl;
}

void Socket::write(const char *buf) {
  cout << "Message sent : " << buf << endl;
}

class SocketManager {
public:
  SocketManager(IPAddress addr, Port p);
  ~SocketManager();
  //SocketManager() = default;                                                  // Do NOT enable this line in order to declare "SocketManager mgr;" in main(). If so no assertion failed at runtime
  void send(const char *str) const;
private:
  IPAddress ip;
  Socket *pSocket;
};

SocketManager::SocketManager(IPAddress addr, Port p) : ip{ addr }, pSocket{ new Socket{ p } } {
  pSocket->open();
}

SocketManager::~SocketManager() {
  pSocket->close();
  delete pSocket;
}

void SocketManager::send(const char *str) const {
  pSocket->write(str);
}

void func(SocketManager mgr) {                                                  // Note : pass by value
  mgr.send("Hello World from func()");
}

int main() {                                                                    // Run in Debug mode. Generates an assertion failed

  {
    SocketManager mgr{ 2002, 0x7F000002 };
    func(mgr);
    mgr.send("Hello World from main()");
  }

  cout << "Press ENTER to quit : ";
  cin.ignore((numeric_limits<streamsize>::max)(), '\n');
}