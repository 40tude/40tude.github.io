#include <iostream>
#include <limits>

using namespace std;

using Port      = int;
using IPAddress = int;

class Socket {
public:
  Socket(Port p);
  void open();
  void close();
  void write(const char *buf);
private:
  Port port;
};

Socket::Socket(Port p) : port{ p } {
}

void Socket::open() {
  cout << "Socket opened" << endl;
}

void Socket::close() {
  cout << "Socket closed" << endl;
}

void Socket::write(const char *buf) {
  cout << "Message sent : " << buf << endl;
}

class SocketManager {
public:
  SocketManager(IPAddress addr, Port p);
  ~SocketManager();
  //SocketManager() = default;                                                    
  SocketManager(const SocketManager& src);                                      // Cpy ctor
  SocketManager& operator=(SocketManager rhs);                                  // Pass by value and no longer const
  void send(const char *str) const;
private:
  IPAddress ip;
  Socket *pSocket;
  void swap(SocketManager& rhs);
};

SocketManager::SocketManager(IPAddress addr, Port p) : ip{ addr }, pSocket{ new Socket{ p } } {
  pSocket->open();
}

SocketManager::~SocketManager() {
  pSocket->close();
  delete pSocket;
}

SocketManager::SocketManager(const SocketManager& src) : ip{ src.ip }, pSocket{ nullptr } {
  if (src.pSocket != nullptr) {
    pSocket = new Socket{ *src.pSocket };
  }
  pSocket->open();
}

SocketManager& SocketManager::operator= (SocketManager rhs) {                   // Pass by value. No longer const
  swap(rhs);
  return *this;
}

void SocketManager::swap(SocketManager& rhs) {
  std::swap(this->ip, rhs.ip);
  std::swap(this->pSocket, rhs.pSocket);
}

void SocketManager::send(const char *str) const {
  pSocket->write(str);
}

int main() {

  {
    SocketManager mgr1{ 2002, 0x7F000001 };
    SocketManager mgr2{ 1441, 0x7F00007F };

    mgr2 = mgr1;
  }

  cout << "Press ENTER to quit : ";
  cin.ignore((numeric_limits<streamsize>::max)(), '\n');
}