#include <iostream>
#include <limits>

using namespace std;

using Port      = int;
using IPAddress = int;

class Socket {
public:
  Socket(Port p);
  void open();
  void close();
  void write(const char *buf);
private:
  Port port;
};

Socket::Socket(Port p) : port{ p } {
}

void Socket::open() {
  cout << "Socket opened" << endl;
}

void Socket::close() {
  cout << "Socket closed" << endl;
}

void Socket::write(const char *buf) {
  cout << "Message sent : " << buf << endl;
}

class SocketManager {
public:
  SocketManager(IPAddress addr, Port p);
  ~SocketManager();
  void send(const char *str) const;
private:
  IPAddress ip;
  Socket *pSocket;
};

SocketManager::SocketManager(IPAddress addr, Port p) : ip{ addr }, pSocket{ new Socket{ p } } { 
                                                                                // The "new" above in the members initialization list create the Socket
  pSocket->open();                                                              
}

SocketManager::~SocketManager() {
  pSocket->close();
  delete pSocket;                                                               // Destroy the Socket
}

void SocketManager::send(const char *str) const {
  pSocket->write(str);
}

int main() {

  {                                                                             // The block allow to see messages from ctor & dtor
    SocketManager mgr{ 2002, 0x7F000001 };
    mgr.send("Hello World.");
  }

  cout << "Press ENTER to quit : ";
  cin.ignore((numeric_limits<streamsize>::max)(), '\n');
}