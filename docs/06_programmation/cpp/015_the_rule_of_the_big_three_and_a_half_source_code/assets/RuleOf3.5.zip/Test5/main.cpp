#include <iostream>
#include <limits>

using namespace std;

using Port      = int;
using IPAddress = int;

class Socket {
public:
  Socket(Port p);
  void open();
  void close();
  void write(const char *buf);
private:
  Port port;
};

Socket::Socket(Port p) : port{ p } {
}

void Socket::open() {
  cout << "Socket opened" << endl;
}

void Socket::close() {
  cout << "Socket closed" << endl;
}

void Socket::write(const char *buf) {
  cout << "Message sent : " << buf << endl;
}

class SocketManager {
public:
  SocketManager(IPAddress addr, Port p);
  ~SocketManager();
  void send(const char *str) const;
private:
  IPAddress ip;
  Socket *pSocket;
};

SocketManager::SocketManager(IPAddress addr, Port p) : ip{ addr }, pSocket{ new Socket{ p } } {
  pSocket->open();
}

SocketManager::~SocketManager() {
  pSocket->close();
  delete pSocket;
}

void SocketManager::send(const char *str) const {
  pSocket->write(str);
}

SocketManager make_SocketManager(const IPAddress& addr, const Port& port) {
  SocketManager temp{ addr, port };
  return temp;
}

SocketManager NRV_make_SocketManager(const IPAddress& addr, const Port& port) {
  return SocketManager{ addr, port };                                           // NRVO : Named Return Value Optimization
}

int main() {                                                                    // Run in Debug mode. Generates an assertion failed

  {
    SocketManager mgr1 = make_SocketManager(2002, 21);
    SocketManager mgr2 = NRV_make_SocketManager(2002, 21);
  }

  cout << "Press ENTER to quit : ";
  cin.ignore((numeric_limits<streamsize>::max)(), '\n');
}