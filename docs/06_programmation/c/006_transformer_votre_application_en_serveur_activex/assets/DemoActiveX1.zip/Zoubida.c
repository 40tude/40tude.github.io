#include "Zoubida.h"

typedef interface tagZoubida_IApp_Interface Zoubida_IApp_Interface;

typedef struct tagZoubida_IApp_VTable
{
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( Zoubida_IApp_Interface __RPC_FAR * This, 
	                                                         REFIID riid, 
	                                                         void __RPC_FAR *__RPC_FAR *ppvObject);

	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( Zoubida_IApp_Interface __RPC_FAR * This);

	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( Zoubida_IApp_Interface __RPC_FAR * This);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( Zoubida_IApp_Interface __RPC_FAR * This, 
	                                                           UINT __RPC_FAR *pctinfo);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( Zoubida_IApp_Interface __RPC_FAR * This, 
	                                                      UINT iTInfo, 
	                                                      LCID lcid, 
	                                                      ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( Zoubida_IApp_Interface __RPC_FAR * This, 
	                                                        REFIID riid, 
	                                                        LPOLESTR __RPC_FAR *rgszNames, 
	                                                        UINT cNames, 
	                                                        LCID lcid, 
	                                                        DISPID __RPC_FAR *rgDispId);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( Zoubida_IApp_Interface __RPC_FAR * This, 
	                                                 DISPID dispIdMember, 
	                                                 REFIID riid, 
	                                                 LCID lcid, 
	                                                 WORD wFlags, 
	                                                 DISPPARAMS __RPC_FAR *pDispParams, 
	                                                 VARIANT __RPC_FAR *pVarResult, 
	                                                 EXCEPINFO __RPC_FAR *pExcepInfo, 
	                                                 UINT __RPC_FAR *puArgErr);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetVisible_) (Zoubida_IApp_Interface __RPC_FAR *This, 
	                                                     VBOOL *visible);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVisible_) (Zoubida_IApp_Interface __RPC_FAR *This, 
	                                                     VBOOL visible);

} Zoubida_IApp_VTable;

typedef interface tagZoubida_IApp_Interface
{
	CONST_VTBL Zoubida_IApp_VTable __RPC_FAR *lpVtbl;
} Zoubida_IApp_Interface;

typedef interface tagZoubida_IScalar_Interface Zoubida_IScalar_Interface;

typedef struct tagZoubida_IScalar_VTable
{
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( Zoubida_IScalar_Interface __RPC_FAR * This, 
	                                                         REFIID riid, 
	                                                         void __RPC_FAR *__RPC_FAR *ppvObject);

	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( Zoubida_IScalar_Interface __RPC_FAR * This);

	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( Zoubida_IScalar_Interface __RPC_FAR * This);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( Zoubida_IScalar_Interface __RPC_FAR * This, 
	                                                           UINT __RPC_FAR *pctinfo);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( Zoubida_IScalar_Interface __RPC_FAR * This, 
	                                                      UINT iTInfo, 
	                                                      LCID lcid, 
	                                                      ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( Zoubida_IScalar_Interface __RPC_FAR * This, 
	                                                        REFIID riid, 
	                                                        LPOLESTR __RPC_FAR *rgszNames, 
	                                                        UINT cNames, 
	                                                        LCID lcid, 
	                                                        DISPID __RPC_FAR *rgDispId);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( Zoubida_IScalar_Interface __RPC_FAR * This, 
	                                                 DISPID dispIdMember, 
	                                                 REFIID riid, 
	                                                 LCID lcid, 
	                                                 WORD wFlags, 
	                                                 DISPPARAMS __RPC_FAR *pDispParams, 
	                                                 VARIANT __RPC_FAR *pVarResult, 
	                                                 EXCEPINFO __RPC_FAR *pExcepInfo, 
	                                                 UINT __RPC_FAR *puArgErr);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Getx_) (Zoubida_IScalar_Interface __RPC_FAR *This, 
	                                               double *x);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Setx_) (Zoubida_IScalar_Interface __RPC_FAR *This, 
	                                               double x);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Gety_) (Zoubida_IScalar_Interface __RPC_FAR *This, 
	                                               double *y);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Sety_) (Zoubida_IScalar_Interface __RPC_FAR *This, 
	                                               double y);

	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Getz_) (Zoubida_IScalar_Interface __RPC_FAR *This, 
	                                               double *z);

} Zoubida_IScalar_VTable;

typedef interface tagZoubida_IScalar_Interface
{
	CONST_VTBL Zoubida_IScalar_VTable __RPC_FAR *lpVtbl;
} Zoubida_IScalar_Interface;

const IID Zoubida_IID_IApp =
	{
		0x771EB434, 0x482B, 0x428B, 0x9A, 0x4, 0x58, 0xE5, 0xF7, 0xEC, 0xDC, 0xFA
	};

const IID Zoubida_IID_IScalar =
	{
		0xEB2322A2, 0xF60, 0x42D8, 0x88, 0x3F, 0x4E, 0x56, 0x3F, 0x97, 0x46, 0xF3
	};

HRESULT CVIFUNC Zoubida_NewIApp (const char *server, int supportMultithreading,
                                 LCID locale, int reserved,
                                 CAObjHandle *objectHandle)
{
	HRESULT __result = S_OK;
	GUID clsid = {0xB2F1F72A, 0x33D1, 0x43D2, 0x80, 0x8, 0xA3, 0xC4, 0x8, 0xC1,
	              0xAA, 0xDF};

	__result = CA_CreateObjectByClassIdEx (&clsid, server, &Zoubida_IID_IApp,
	                                       supportMultithreading, locale,
	                                       reserved, objectHandle);

	return __result;
}

HRESULT CVIFUNC Zoubida_OpenIApp (const char *fileName, const char *server,
                                  int supportMultithreading, LCID locale,
                                  int reserved, CAObjHandle *objectHandle)
{
	HRESULT __result = S_OK;
	GUID clsid = {0xB2F1F72A, 0x33D1, 0x43D2, 0x80, 0x8, 0xA3, 0xC4, 0x8, 0xC1,
	              0xAA, 0xDF};

	__result = CA_LoadObjectFromFileByClassIdEx (fileName, &clsid, server,
	                                             &Zoubida_IID_IApp,
	                                             supportMultithreading, locale,
	                                             reserved, objectHandle);

	return __result;
}

HRESULT CVIFUNC Zoubida_ActiveIApp (const char *server,
                                    int supportMultithreading, LCID locale,
                                    int reserved, CAObjHandle *objectHandle)
{
	HRESULT __result = S_OK;
	GUID clsid = {0xB2F1F72A, 0x33D1, 0x43D2, 0x80, 0x8, 0xA3, 0xC4, 0x8, 0xC1,
	              0xAA, 0xDF};

	__result = CA_GetActiveObjectByClassIdEx (&clsid, server,
	                                          &Zoubida_IID_IApp,
	                                          supportMultithreading, locale,
	                                          reserved, objectHandle);

	return __result;
}

HRESULT CVIFUNC Zoubida_IAppGetVisible (CAObjHandle objectHandle,
                                        ERRORINFO *errorInfo, VBOOL *visible)
{
	HRESULT __result = S_OK;
	Zoubida_IApp_Interface * __vtblIFacePtr = 0;
	int __didAddRef;
	int __errorInfoPresent = 0;
	VBOOL visible__Temp;

	__caErrChk (CA_GetInterfaceFromObjHandle (objectHandle, &Zoubida_IID_IApp,
	                                          0, &__vtblIFacePtr, &__didAddRef));
	__caErrChk (__vtblIFacePtr->lpVtbl->GetVisible_ (__vtblIFacePtr,
	                                                 &visible__Temp));

	if (visible)
		{
		*visible = visible__Temp;
		}

Error:
	if (__vtblIFacePtr && __didAddRef)
		__vtblIFacePtr->lpVtbl->Release (__vtblIFacePtr);
	CA_FillErrorInfoEx (objectHandle, &Zoubida_IID_IApp, __result, errorInfo,
	                    &__errorInfoPresent);
	if (__errorInfoPresent)
		__result = DISP_E_EXCEPTION;
	return __result;
}

HRESULT CVIFUNC Zoubida_IAppSetVisible (CAObjHandle objectHandle,
                                        ERRORINFO *errorInfo, VBOOL visible)
{
	HRESULT __result = S_OK;
	Zoubida_IApp_Interface * __vtblIFacePtr = 0;
	int __didAddRef;
	int __errorInfoPresent = 0;

	__caErrChk (CA_GetInterfaceFromObjHandle (objectHandle, &Zoubida_IID_IApp,
	                                          0, &__vtblIFacePtr, &__didAddRef));
	__caErrChk (__vtblIFacePtr->lpVtbl->SetVisible_ (__vtblIFacePtr, visible));

Error:
	if (__vtblIFacePtr && __didAddRef)
		__vtblIFacePtr->lpVtbl->Release (__vtblIFacePtr);
	CA_FillErrorInfoEx (objectHandle, &Zoubida_IID_IApp, __result, errorInfo,
	                    &__errorInfoPresent);
	if (__errorInfoPresent)
		__result = DISP_E_EXCEPTION;
	return __result;
}

HRESULT CVIFUNC Zoubida_NewIScalar (const char *server,
                                    int supportMultithreading, LCID locale,
                                    int reserved, CAObjHandle *objectHandle)
{
	HRESULT __result = S_OK;
	GUID clsid = {0xB2F1F72A, 0x33D1, 0x43D2, 0x80, 0x8, 0xA3, 0xC4, 0x8, 0xC1,
	              0xAA, 0xDF};

	__result = CA_CreateObjectByClassIdEx (&clsid, server,
	                                       &Zoubida_IID_IScalar,
	                                       supportMultithreading, locale,
	                                       reserved, objectHandle);

	return __result;
}

HRESULT CVIFUNC Zoubida_OpenIScalar (const char *fileName, const char *server,
                                     int supportMultithreading, LCID locale,
                                     int reserved, CAObjHandle *objectHandle)
{
	HRESULT __result = S_OK;
	GUID clsid = {0xB2F1F72A, 0x33D1, 0x43D2, 0x80, 0x8, 0xA3, 0xC4, 0x8, 0xC1,
	              0xAA, 0xDF};

	__result = CA_LoadObjectFromFileByClassIdEx (fileName, &clsid, server,
	                                             &Zoubida_IID_IScalar,
	                                             supportMultithreading, locale,
	                                             reserved, objectHandle);

	return __result;
}

HRESULT CVIFUNC Zoubida_ActiveIScalar (const char *server,
                                       int supportMultithreading, LCID locale,
                                       int reserved, CAObjHandle *objectHandle)
{
	HRESULT __result = S_OK;
	GUID clsid = {0xB2F1F72A, 0x33D1, 0x43D2, 0x80, 0x8, 0xA3, 0xC4, 0x8, 0xC1,
	              0xAA, 0xDF};

	__result = CA_GetActiveObjectByClassIdEx (&clsid, server,
	                                          &Zoubida_IID_IScalar,
	                                          supportMultithreading, locale,
	                                          reserved, objectHandle);

	return __result;
}

HRESULT CVIFUNC Zoubida_IScalarGetx (CAObjHandle objectHandle,
                                     ERRORINFO *errorInfo, double *x)
{
	HRESULT __result = S_OK;
	Zoubida_IScalar_Interface * __vtblIFacePtr = 0;
	int __didAddRef;
	int __errorInfoPresent = 0;
	double x__Temp;

	__caErrChk (CA_GetInterfaceFromObjHandle (objectHandle,
	                                          &Zoubida_IID_IScalar, 0,
	                                          &__vtblIFacePtr, &__didAddRef));
	__caErrChk (__vtblIFacePtr->lpVtbl->Getx_ (__vtblIFacePtr, &x__Temp));

	if (x)
		{
		*x = x__Temp;
		}

Error:
	if (__vtblIFacePtr && __didAddRef)
		__vtblIFacePtr->lpVtbl->Release (__vtblIFacePtr);
	CA_FillErrorInfoEx (objectHandle, &Zoubida_IID_IScalar, __result,
	                    errorInfo, &__errorInfoPresent);
	if (__errorInfoPresent)
		__result = DISP_E_EXCEPTION;
	return __result;
}

HRESULT CVIFUNC Zoubida_IScalarSetx (CAObjHandle objectHandle,
                                     ERRORINFO *errorInfo, double x)
{
	HRESULT __result = S_OK;
	Zoubida_IScalar_Interface * __vtblIFacePtr = 0;
	int __didAddRef;
	int __errorInfoPresent = 0;

	__caErrChk (CA_GetInterfaceFromObjHandle (objectHandle,
	                                          &Zoubida_IID_IScalar, 0,
	                                          &__vtblIFacePtr, &__didAddRef));
	__caErrChk (__vtblIFacePtr->lpVtbl->Setx_ (__vtblIFacePtr, x));

Error:
	if (__vtblIFacePtr && __didAddRef)
		__vtblIFacePtr->lpVtbl->Release (__vtblIFacePtr);
	CA_FillErrorInfoEx (objectHandle, &Zoubida_IID_IScalar, __result,
	                    errorInfo, &__errorInfoPresent);
	if (__errorInfoPresent)
		__result = DISP_E_EXCEPTION;
	return __result;
}

HRESULT CVIFUNC Zoubida_IScalarGety (CAObjHandle objectHandle,
                                     ERRORINFO *errorInfo, double *y)
{
	HRESULT __result = S_OK;
	Zoubida_IScalar_Interface * __vtblIFacePtr = 0;
	int __didAddRef;
	int __errorInfoPresent = 0;
	double y__Temp;

	__caErrChk (CA_GetInterfaceFromObjHandle (objectHandle,
	                                          &Zoubida_IID_IScalar, 0,
	                                          &__vtblIFacePtr, &__didAddRef));
	__caErrChk (__vtblIFacePtr->lpVtbl->Gety_ (__vtblIFacePtr, &y__Temp));

	if (y)
		{
		*y = y__Temp;
		}

Error:
	if (__vtblIFacePtr && __didAddRef)
		__vtblIFacePtr->lpVtbl->Release (__vtblIFacePtr);
	CA_FillErrorInfoEx (objectHandle, &Zoubida_IID_IScalar, __result,
	                    errorInfo, &__errorInfoPresent);
	if (__errorInfoPresent)
		__result = DISP_E_EXCEPTION;
	return __result;
}

HRESULT CVIFUNC Zoubida_IScalarSety (CAObjHandle objectHandle,
                                     ERRORINFO *errorInfo, double y)
{
	HRESULT __result = S_OK;
	Zoubida_IScalar_Interface * __vtblIFacePtr = 0;
	int __didAddRef;
	int __errorInfoPresent = 0;

	__caErrChk (CA_GetInterfaceFromObjHandle (objectHandle,
	                                          &Zoubida_IID_IScalar, 0,
	                                          &__vtblIFacePtr, &__didAddRef));
	__caErrChk (__vtblIFacePtr->lpVtbl->Sety_ (__vtblIFacePtr, y));

Error:
	if (__vtblIFacePtr && __didAddRef)
		__vtblIFacePtr->lpVtbl->Release (__vtblIFacePtr);
	CA_FillErrorInfoEx (objectHandle, &Zoubida_IID_IScalar, __result,
	                    errorInfo, &__errorInfoPresent);
	if (__errorInfoPresent)
		__result = DISP_E_EXCEPTION;
	return __result;
}

HRESULT CVIFUNC Zoubida_IScalarGetz (CAObjHandle objectHandle,
                                     ERRORINFO *errorInfo, double *z)
{
	HRESULT __result = S_OK;
	Zoubida_IScalar_Interface * __vtblIFacePtr = 0;
	int __didAddRef;
	int __errorInfoPresent = 0;
	double z__Temp;

	__caErrChk (CA_GetInterfaceFromObjHandle (objectHandle,
	                                          &Zoubida_IID_IScalar, 0,
	                                          &__vtblIFacePtr, &__didAddRef));
	__caErrChk (__vtblIFacePtr->lpVtbl->Getz_ (__vtblIFacePtr, &z__Temp));

	if (z)
		{
		*z = z__Temp;
		}

Error:
	if (__vtblIFacePtr && __didAddRef)
		__vtblIFacePtr->lpVtbl->Release (__vtblIFacePtr);
	CA_FillErrorInfoEx (objectHandle, &Zoubida_IID_IScalar, __result,
	                    errorInfo, &__errorInfoPresent);
	if (__errorInfoPresent)
		__result = DISP_E_EXCEPTION;
	return __result;
}
