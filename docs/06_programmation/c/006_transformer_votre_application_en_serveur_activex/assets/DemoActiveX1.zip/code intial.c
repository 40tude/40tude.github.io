#include "Application_axs.h"
#include <cvirte.h>
#include <userint.h>
#include "server.h" 
#include "globals.h"

int __stdcall WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow){
	
	int		runServer = 0;
	char  errBuf [500] = {0};
	//int		panelHandle; 				// now declared in globals.h	    

	if (InitCVIRTE (hInstance, 0, 0) == 0)
		return -1;	// Out of memory

	// ActiveX server initialization
	if (FAILED (CaSrvrZoubidaInit (hInstance, lpszCmdLine, &runServer, errBuf, sizeof(errBuf))))
		return -1;	// Server initialization error.

	if (runServer){
		// ...
		// Your initialization code
		// ...
		if ((ghPanel = LoadPanel (0, "server.uir", PANEL)) < 0)
			return -1;
		DisplayPanel (ghPanel);    
		gbVisible = VTRUE;     
		RunUserInterface ();	// Process messages

		// ...
		// Your cleanup code
		// ...
		DiscardPanel (ghPanel);     
	}

	// ActiveX server cleanup
	CaSrvrZoubidaUninit (hInstance);
	return 0;
}

/*
#include <cvirte.h>
#include <userint.h>
#include "server.h"

// ----------------------------------------------------------------------------
int __stdcall WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                       LPSTR lpszCmdLine, int nCmdShow){

	int panelHandle; 	 

	if (InitCVIRTE (hInstance, 0, 0) == 0)
		return -1;	// Out of memory

	if ((panelHandle = LoadPanel (0, "server.uir", PANEL)) < 0)
		return -1;

	DisplayPanel (panelHandle);     
	RunUserInterface ();
	DiscardPanel (panelHandle);         
	return 0;
}
*/

// ----------------------------------------------------------------------------
int CVICALLBACK QuitCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	
	switch (event) {
		case EVENT_COMMIT:
			QuitUserInterface (0);
		break;
	}
	return 0;
}

// ----------------------------------------------------------------------------
int CVICALLBACK OnInput (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	
	double x,y;
	
	switch (event) {
		case EVENT_COMMIT:
			GetCtrlVal(panel, PANEL_X, &x);	
			GetCtrlVal(panel, PANEL_Y, &y);
			SetCtrlVal(panel, PANEL_XY, x*y);
		break;
	}
	return 0;
}
