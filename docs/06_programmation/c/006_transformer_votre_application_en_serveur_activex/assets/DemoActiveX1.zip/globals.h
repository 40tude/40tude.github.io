int		ghPanel; 
VBOOL gbVisible;	    

