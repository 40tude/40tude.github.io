#ifndef _ZOUBIDA_H
#define _ZOUBIDA_H

#include <cviauto.h>

#ifdef __cplusplus
    extern "C" {
#endif
extern const IID Zoubida_IID_IApp;

extern const IID Zoubida_IID_IScalar;

HRESULT CVIFUNC Zoubida_NewIApp (const char *server, int supportMultithreading,
                                 LCID locale, int reserved,
                                 CAObjHandle *objectHandle);

HRESULT CVIFUNC Zoubida_OpenIApp (const char *fileName, const char *server,
                                  int supportMultithreading, LCID locale,
                                  int reserved, CAObjHandle *objectHandle);

HRESULT CVIFUNC Zoubida_ActiveIApp (const char *server,
                                    int supportMultithreading, LCID locale,
                                    int reserved, CAObjHandle *objectHandle);

HRESULT CVIFUNC Zoubida_IAppGetVisible (CAObjHandle objectHandle,
                                        ERRORINFO *errorInfo, VBOOL *visible);

HRESULT CVIFUNC Zoubida_IAppSetVisible (CAObjHandle objectHandle,
                                        ERRORINFO *errorInfo, VBOOL visible);

HRESULT CVIFUNC Zoubida_NewIScalar (const char *server,
                                    int supportMultithreading, LCID locale,
                                    int reserved, CAObjHandle *objectHandle);

HRESULT CVIFUNC Zoubida_OpenIScalar (const char *fileName, const char *server,
                                     int supportMultithreading, LCID locale,
                                     int reserved, CAObjHandle *objectHandle);

HRESULT CVIFUNC Zoubida_ActiveIScalar (const char *server,
                                       int supportMultithreading, LCID locale,
                                       int reserved, CAObjHandle *objectHandle);

HRESULT CVIFUNC Zoubida_IScalarGetx (CAObjHandle objectHandle,
                                     ERRORINFO *errorInfo, double *x);

HRESULT CVIFUNC Zoubida_IScalarSetx (CAObjHandle objectHandle,
                                     ERRORINFO *errorInfo, double x);

HRESULT CVIFUNC Zoubida_IScalarGety (CAObjHandle objectHandle,
                                     ERRORINFO *errorInfo, double *y);

HRESULT CVIFUNC Zoubida_IScalarSety (CAObjHandle objectHandle,
                                     ERRORINFO *errorInfo, double y);

HRESULT CVIFUNC Zoubida_IScalarGetz (CAObjHandle objectHandle,
                                     ERRORINFO *errorInfo, double *z);
#ifdef __cplusplus
    }
#endif
#endif /* _ZOUBIDA_H */
