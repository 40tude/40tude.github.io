#include <cviauto.h>
#include "Zoubida.h"
#include <cvirte.h>

int main (int argc, char *argv[]) {
	
	CAObjHandle hIScalar;
	double			z;
	
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;    /* out of memory */

	//Zoubida_NewIScalar (NULL, 1, LOCALE_NEUTRAL, 0, &hIScalar);
	Zoubida_ActiveIScalar (NULL, 1, LOCALE_NEUTRAL, 0, &hIScalar);
	
	Zoubida_IScalarSetx (hIScalar, NULL, 3);
	Zoubida_IScalarSety (hIScalar, NULL, -4);
	Zoubida_IScalarGetz (hIScalar, NULL, &z);

	CA_DiscardObjHandle (hIScalar);
	hIScalar=0;
	return 0;
}
