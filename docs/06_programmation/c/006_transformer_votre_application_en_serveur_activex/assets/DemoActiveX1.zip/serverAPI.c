#include "Application_axs.h"
#include <userint.h>
#include "server.h"
#include "globals.h"

HRESULT CVIFUNC MultObjIAppget_Visible (CAServerObjHandle objHandle, VARIANT_BOOL* Visible){
	
	HRESULT	hr = S_OK;
	
	if (Visible == NULL)
		return E_INVALIDARG;
	
	*Visible = gbVisible;
	return hr;           
}

HRESULT CVIFUNC MultObjIAppput_Visible (CAServerObjHandle objHandle, VARIANT_BOOL Visible){
	
	HRESULT				hr = S_OK; 
	static VBOOL	bLockedObj=VFALSE;		// indicates if object is locked         
	
	gbVisible = Visible;
	if (Visible) {
		DisplayPanel (ghPanel);
		// Check if the object was inactive
		if (!bLockedObj) {
			// Lock the object as the UI is now visible
			hr = CA_ServerLockActiveObject (objHandle);
			if(hr<0)
				return hr;
			bLockedObj = VTRUE;
		}
	} else {
		HidePanel (ghPanel);
		// Check if the object was active
		if (bLockedObj) {
			// Unlock the object as the UI is now invisible
			hr = CA_ServerUnlockActiveObject (objHandle);
			if(hr<0)
				return hr;
			bLockedObj = VFALSE;
		}
	}
	return hr;           
}

HRESULT CVIFUNC MultObjIScalarget_x (CAServerObjHandle objHandle, double* x){
	
	HRESULT	hr = S_OK;  
	
	GetCtrlVal(ghPanel, PANEL_X, x);	  
	return hr;           
}

HRESULT CVIFUNC MultObjIScalarput_x (CAServerObjHandle objHandle, double x){
	
	HRESULT	hr = S_OK;  
	
	SetCtrlVal(ghPanel, PANEL_X, x);
	OnInput(ghPanel, 0, EVENT_COMMIT, 0, 0, 0);
	return hr;           
}

HRESULT CVIFUNC MultObjIScalarget_y (CAServerObjHandle objHandle, double* y){
	
	HRESULT	hr = S_OK;  
	
	GetCtrlVal(ghPanel, PANEL_Y, y);
	return hr;           
}

HRESULT CVIFUNC MultObjIScalarput_y (CAServerObjHandle objHandle, double y){
	
	HRESULT	hr = S_OK; 
	
	SetCtrlVal(ghPanel, PANEL_Y, y);
	OnInput(ghPanel, 0, EVENT_COMMIT, 0, 0, 0);
	return hr;           
}

HRESULT CVIFUNC MultObjIScalarget_z (CAServerObjHandle objHandle, double* z){
	
	HRESULT	hr = S_OK;  
	
	GetCtrlVal(ghPanel, PANEL_XY, z);	
	return hr;           
}
	
