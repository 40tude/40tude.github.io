/******************************************************************************/
/* WARNING: LabWindows/CVI generates this file. Do not add to, delete from,   */
/*          or otherwise modify the contents of this file.                    */
/******************************************************************************/

#include "Application_axs.h"

/******************************************************************************/
/* Const Definitions of GUIDs                                                 */
/******************************************************************************/

const GUID LIBID_Zoubida = {0x1BF7CEC2, 0xA80E, 0x4ACE, 0x9A, 0xD, 0xEE,
                            0x18, 0x14, 0xB5, 0x3C, 0xE7};
const GUID CLSID_MultObj = {0xB2F1F72A, 0x33D1, 0x43D2, 0x80, 0x8, 0xA3,
                            0xC4, 0x8, 0xC1, 0xAA, 0xDF};
const GUID IID_IApp = {0x771EB434, 0x482B, 0x428B, 0x9A, 0x4, 0x58, 0xE5,
                       0xF7, 0xEC, 0xDC, 0xFA};
const GUID IID_IScalar = {0xEB2322A2, 0xF60, 0x42D8, 0x88, 0x3F, 0x4E,
                          0x56, 0x3F, 0x97, 0x46, 0xF3};

/******************************************************************************/
/* Definitions of interface methods                                           */
/******************************************************************************/

static STDMETHODIMP CaSrvrMultObjIAppget_Visible (IApp* This,
                                                  VARIANT_BOOL* Visible)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (MultObjIAppget_Visible (objHandle, Visible));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrMultObjIAppput_Visible (IApp* This,
                                                  VARIANT_BOOL Visible)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (MultObjIAppput_Visible (objHandle, Visible));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrMultObjIScalarget_x (IScalar* This, double* x)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (MultObjIScalarget_x (objHandle, x));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrMultObjIScalarput_x (IScalar* This, double x)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (MultObjIScalarput_x (objHandle, x));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrMultObjIScalarget_y (IScalar* This, double* y)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (MultObjIScalarget_y (objHandle, y));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrMultObjIScalarput_y (IScalar* This, double y)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (MultObjIScalarput_y (objHandle, y));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrMultObjIScalarget_z (IScalar* This, double* z)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (MultObjIScalarget_z (objHandle, z));

Error:
	return __result;
}


/******************************************************************************/
/* Definitions of CVI ActiveX Server API structures                           */
/******************************************************************************/

static void * MultObjIAppFuncArr[] =
	{
		(void *)CaSrvrMultObjIAppget_Visible,
    (void *)CaSrvrMultObjIAppput_Visible
	};

static CAServerUserVtbl MultObjIAppVtbl =
	{
		(int)(sizeof(MultObjIAppFuncArr)/sizeof(MultObjIAppFuncArr[0])),
    (void **)&MultObjIAppFuncArr
	};

static CAServerDispatchDesc MultObjIAppDispatchDesc =
	{
		0,
    &LIBID_Zoubida,
    1,
    0,
    0
	};

static CAServerIfaceDesc MultObjIAppIfaceDesc =
	{
		IfaceType_kIDispatchDerived,
    &MultObjIAppVtbl,
    &IID_IApp,
    &MultObjIAppDispatchDesc
	};

static void * MultObjIScalarFuncArr[] =
	{
		(void *)CaSrvrMultObjIScalarget_x,
    (void *)CaSrvrMultObjIScalarput_x,
    (void *)CaSrvrMultObjIScalarget_y,
    (void *)CaSrvrMultObjIScalarput_y,
    (void *)CaSrvrMultObjIScalarget_z
	};

static CAServerUserVtbl MultObjIScalarVtbl =
	{
		(int)(sizeof(MultObjIScalarFuncArr)/sizeof(MultObjIScalarFuncArr[0])),
    (void **)&MultObjIScalarFuncArr
	};

static CAServerDispatchDesc MultObjIScalarDispatchDesc =
	{
		0,
    &LIBID_Zoubida,
    1,
    0,
    1
	};

static CAServerIfaceDesc MultObjIScalarIfaceDesc =
	{
		IfaceType_kIDispatchDerived,
    &MultObjIScalarVtbl,
    &IID_IScalar,
    &MultObjIScalarDispatchDesc
	};

static CAServerIfaceDesc * MultObjIfaceDescList[] =
	{
		&MultObjIAppIfaceDesc,
    &MultObjIScalarIfaceDesc
	};

static CAServerObjDesc MultObjObjDesc =
	{
		"Zoubida.MultObj",
    1,
    &CLSID_MultObj,
    NULL,
    0,
    ServerObjType_SingleDocApplication,
    0,
    0,
    0,
    NULL,
    (int)(sizeof(MultObjIfaceDescList)/sizeof(MultObjIfaceDescList[0])),
    MultObjIfaceDescList
	};

static CAServerObjDesc * ZoubidaObjDescList[] =
	{
		&MultObjObjDesc
	};

static CAServerTypeLibDesc ZoubidaTypeLibDesc =
	{
		&LIBID_Zoubida,
    1,
    0,
    0,
    SYS_WIN32
	};

static CAServerModuleDesc ZoubidaModuleDesc =
	{
		ThreadingModel_Single,
    DllMultiThreadingModel_None,
    0,
    NULL,
    (int)(sizeof(ZoubidaObjDescList)/sizeof(ZoubidaObjDescList[0])),
    ZoubidaObjDescList,
    &ZoubidaTypeLibDesc
	};


/******************************************************************************/
/* Definitions of functions and variables related to the server module        */
/******************************************************************************/

STDMETHODIMP CaSrvrZoubidaInit (
             	HINSTANCE hinst, char *cmdLine, int *runServer,
             	char *errStrBuf, size_t bufSize)
{
	return CA_InitActiveXServer (hinst, kServerModuleType_Exe, cmdLine,
	                             &ZoubidaModuleDesc,
	                             runServer, errStrBuf, bufSize);
}

STDMETHODIMP CaSrvrZoubidaUninit (HINSTANCE hinst)
{
	return CA_CloseActiveXServer (hinst);
}
